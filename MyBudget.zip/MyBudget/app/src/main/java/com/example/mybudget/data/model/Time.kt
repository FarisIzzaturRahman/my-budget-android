package com.example.mybudget.data.model

data class Time(
    var year: String? = null,
    var month: String? = null,
    var date: String? = null,
    var day: String? = null
)