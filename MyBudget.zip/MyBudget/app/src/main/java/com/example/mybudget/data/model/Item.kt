package com.example.mybudget.data.model

data class Item(
    var name: String? = null,
    var price: String? = null,
    var time: Time? = null
)